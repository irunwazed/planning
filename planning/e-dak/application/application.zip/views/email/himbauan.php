<html>
    <head>

    </head>
    <body>
        <div>
            <div>
                <center>
                <table>
                    <tr>
                        <td rowspan="3" style="width: 20%;height: 50px;">
                            <img style="height: 100%;" src="cid:-=set-logo=-" alt="logo"/>
                        </td>
                        <td style="font-size: 11px; text-align: center;">PEMERINTAH KABUPATEN KOLAKA UTARA</td>
                    </tr>
                    <tr>
                        <td style="font-size: 12px; text-align: center;">SEKRETARIAT DAERAH</td>
                    </tr>
                    <tr>
                        <td style="font-size: 7px; text-align: center;">Kompleks Perkantoran Ponggiha Lasusua Kab. Kolaka Utara</td>
                    </tr>
                </table>
                </center>
                
                <hr>
            </div>
            <div>
                <h2  style="text-align: center;"><u>HIMBAUAN</u></h2>
            </div>
            <table>
                <tr>
                    <td colspan="2">Kepada Yth.</td>
                </tr>
                <tr>
                    <td colspan="2">Para Kepala Perangkat Daerah</td>
                </tr>
                <tr>
                    <td colspan="2">Pengelolah Dana Alokasi Khusus (DAK)</td>
                </tr>
                <tr>
                    <td colspan="2">Masing-Masing</td>
                </tr>
                <tr>
                    <td colspan="2">di.-</td>
                </tr>
                <tr>
                    <td></td>
                    <td>Tempat</td>
                </tr>
            </table>
            <p style="text-align: justify;">
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Sehubungan dengan pelaksanaan Kegiatan yang bersumber dari Dana Alokasi Khusus (DAK) telah memasuki masa periode pelaporan Triwulan <?=$triwulan?>, maka dengan ini kami menghimbau kepada seluruh Kepala Perangkat Daerah untuk memerintahkan Para Pejabat Pembuat Komitmen (PPK) untuk melaporkan kemajuan/progres keuangan dan fisik melalui Aplikasi Si-PANDAI dengan membuka website 
            <a href="http://sipandai.bappedakolut.com">http://sipandai.bappedakolut.com</a>
              selambat lambatnya 2 Hari kedepan
            </p>
            <p style="text-align: justify;">
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Demikian himbauan ini disampaikan atas perhatianya kami ucapkan terima  Kasih.
            </p>

            <div style="float: right;">
                <table>
                    <tr>
                        <td>An.</td>
                        <td>Bupati Kolaka Utara</td>
                    </tr>
                    <tr>
                        <td></td>
                        <td>Sekretaris Daerah</td>
                    </tr>
                    <tr style="height:20px;">
                        <td colspan="2"></td>
                    </tr>
                    <tr>
                        <td colspan="2" style="text-align: center;">TTD</td>
                    </tr>
                    <tr style="height:20px;">
                        <td colspan="2"></td>
                    </tr>
                    <tr>
                        <td colspan="2" style="text-align: center;"><u>Taupiq S., SP,MM</u></td>
                    </tr>
                    <tr>
                        <td colspan="2" style="text-align: center;">Pembina TK I Gol IV/b</td>
                    </tr>
                    <tr>
                        <td colspan="2" style="text-align: center;"> Nip. 19680603 199703 1 007</td>
                    </tr>
                </table>
            </div>
        </div>
    </body>
</html>