<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class RkpdController extends CI_Controller {

    public function __construct()
    {
		parent::__construct();
        $this->load->model('DataModel');
        $this->load->library('Filter');
        $this->levelArr = array(1,3);
    }

    public function view(){
        $this->filter->cekLoginOut($this->levelArr);
        
        $data = array();
        $data['judul'] = "Laporan RKPD";

        $file['content'] = $this->load->view('components/laporan-rkpd/content', $data, true);
        $file['script'] = $this->load->view('components/laporan-rkpd/script', $data, true);
        $this->load->view('includes/layout', $file);
	}

    public function cetak($save = ''){
        
        // error_reporting(0);
        $status = false;
        $pesan = "Data Tidak Ditemukan";
        $post = $this->input->post();

        $dataIndikator = array();
        $linkSavePDF = 'monev/pdf/evaluasi';
        $nameFile = 'laporan';
        $pageStatus = 'miring';
        
        $pesan = "Berhasil Mendapatkan Data";
        $status = true;
        $dataAll = array();

        $tahun = $post['tahun'];
        $triwulan = 1;
        $post['triwulan'] = $triwulan;

        // print_r($post);
        
        $dataAll = $this->setData($post);
        $dataRpjmd = $this->DataModel->getStatusRpjmd();
        $tahunKe = $tahun - $dataRpjmd->tb_rpjmd_tahun + 1;
        // $dataAll = $this->DataModel->getLraOpd($post['cetakopd'], $post['cetaktahun']);
        // $dataOpd = $this->DataModel->selectOneOpdByKode($post['cetakopd']);


        $kirim = array(
            // "dataOpd" => $dataOpd,
            "triwulan" => $triwulan,
            "tahun" => $tahun,
            "tahunKe" => $tahunKe,
            "data" => $dataAll,
            "status" => $status,
            "post" => $post,
            "pesan" => $pesan,
        );

        if($save == 'pdf'){
            $this->load->library('M_pdf');
            $this->m_pdf->getPdf($nameFile, $linkSavePDF, $kirim, $pageStatus);
        }else if($save == 'print'){
            $kirim['print'] = true;
            $this->load->view($linkSavePDF, $kirim);
        }else if($save == 'excel'){
            $this->exportExcelIndikator($dataType, $nameFile, $kirim, $kirim);
        }else{
            echo json_encode($kirim);
        }
    }

    public function setData($post){

        
       $dataAll = array();
       return $dataAll;

    }

}