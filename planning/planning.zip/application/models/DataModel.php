<?php

class DataModel extends CI_Model
{
    
}